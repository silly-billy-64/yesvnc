const resetBtn = document.querySelector("#reset-btn")
const blacklist = document.querySelector("#blacklist")
const extensionNames = document.querySelector("#extension-names")
let resetConfirmed = false

const defaultOptions = {
    maxSites: 8,
    threshold: 1,
    darkTheme: false
}

function updateDarkMode() {
    if (document.querySelector("#dark-mode").checked) {
        document.body.classList.add("dark")
    } else {
        document.body.classList.remove("dark")
    }
}

function getOptions() {
    return {
        maxSites: document.querySelector("#max-sites").value || 5,
        threshold: document.querySelector("#threshold").value || 1,
        darkTheme: document.querySelector("#dark-mode").checked,
        blacklist: blacklist.value.trim() || "",
        extensionNames: extensionNames.checked
    }
}

document.querySelector("form").addEventListener("submit", (e) => {
    e.preventDefault()
    let optionsToSet = getOptions()
    chrome.storage.local.set({options: optionsToSet})
    updateDarkMode()
})

function applyOptions(options) {
    document.querySelector("#max-sites").value = options.maxSites
    document.querySelector("#threshold").value = options.threshold
    document.querySelector("#dark-mode").checked = options.darkTheme
    chrome.permissions.contains({permissions: ['management']}, (result) => {
        if (!result) {
            extensionNames.checked = false
            let newOptions = options
            newOptions.extensionNames = false
            chrome.storage.local.set({options: newOptions})
        } else {
            extensionNames.checked = options.extensionNames && result
        }
    })
    blacklist.value = options.blacklist || ""
}

chrome.storage.local.get("options").then((options) => {
    options = options.options
    applyOptions(options)

    if (options.darkTheme) {
        document.body.classList.add("dark")
    }
}).catch(() => {
    applyOptions(defaultOptions)
})

resetBtn.addEventListener("click", () => {
    if (!resetConfirmed) {
        resetBtn.innerText = "Are you sure?"
        resetConfirmed = true
        return
    }
    chrome.storage.local.clear().then(() => {applyOptions(defaultOptions); updateDarkMode(); chrome.storage.local.remove("options")})
    resetBtn.remove()
    resetConfirmed = false
})

extensionNames.addEventListener("change", () => {
    chrome.permissions.contains({permissions: ['management']}, (result) => {
        if (result) {
            let optionsToSet = getOptions()
            optionsToSet.extensionNames = extensionNames.checked
            chrome.storage.local.set({options: optionsToSet})
        } else {
            chrome.permissions.request({
                permissions: ['management']
            }, (granted) => {
                if (granted) {
                    let optionsToSet = getOptions()
                    optionsToSet.extensionNames = extensionNames.checked
                    chrome.storage.local.set({options: optionsToSet})    
                } else {
                    extensionNames.checked = false
                }
            })
        }
    })
})