const liTemplate = document.querySelector("template#li-template")
const mainList = document.querySelector("#main-list")
const noResults = document.querySelector("#no-results")
const showAll = document.querySelector("#show-all")
let showingAll = false

const overrides = {
    "media-app": "Media",
    "newtab": "New Tab",
    "settings": "Settings",
    "os-settings": "ChromeOS Settings",
    "print": "Print Dialog",
    "file-manager": "My Files",
    "calculator.apps.chrome": "Calculator",
    "canvas.apps.chrome": "Chrome Canvas",
    "screencast.apps.chrome": "Screencast",
    "cursive.apps.chrome": "Cursive"
}

function formatTime(seconds) {
    let hours = Math.floor(seconds / 3600);
    let minutes = Math.floor((seconds % 3600) / 60);
    
    let output = '';
    
    if (hours > 0) {
      output += hours + 'h';
    }
    
    if (minutes > 0 || hours == 0) {
      output += ' ' + minutes + 'm';
    }
    
    return output;
  }

function sortFunction(a, b) {
    if (a.time < b.time) {
        return 1
    }
    if (a.time > b.time) {
        return -1
    }
    return 0
}

function fallbackIcon(hostname, options) {
    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")
    canvas.width = 64
    canvas.height = 64
    ctx.fillStyle = options?.darkTheme ? "rgb(100, 100, 100)" : "rgb(30, 30, 30)"
    ctx.fillRect(0, 0, 60, 60)
    ctx.fillStyle = "white"
    ctx.font = "35px sans-serif"
    var textWidth = ctx.measureText("H").width
    ctx.fillText(hostname.substring(0, 1).toUpperCase(), canvas.width/2 - textWidth/1.8, 42.5, canvas.width)
    return canvas.toDataURL()
}

function refresh() {
    let totalTime = 0
    mainList.querySelectorAll("li.site")?.forEach(e => e.remove())
    chrome.storage.local.get().then((sites) => {
        let siteArray = []
        let options = sites["options"]
        if (options?.darkTheme) {
            document.body.classList.add("dark")
        }
        for (let site in sites) {
            if (site !== "options" && !site.startsWith("FAVICON_")) {
                totalTime += sites[site]
            }
            if (sites[site] >= (options?.threshold * 60 || 60) && site !== "options" && !(options?.blacklist || "").split("\n").includes(site) && !site.startsWith("FAVICON_")) {
                siteArray.push({hostname: site, time: sites[site]})
            }
        }
        siteArray.sort(sortFunction)
        if (!showingAll) siteArray = siteArray.slice(0, options?.maxSites || 8)
        let siteIndex = 0
        function nextSite() {
            if (siteIndex == siteArray.length) {
                return
            }
            const site = siteArray[siteIndex]
            const clone = liTemplate.content.cloneNode(true)
            clone.querySelector(".hostname").innerText = overrides[site.hostname] || site.hostname
            clone.querySelector(".time").innerText = formatTime(site.time)
            clone.querySelector(".favicon").src = sites["FAVICON_" + site.hostname] || fallbackIcon(site.hostname)
            if (options.extensionNames && /^[a-z]{32}$/.test(site.hostname)) {
                try {
                    chrome.management.get(site.hostname, (extension) => {
                        if (extension) {
                            clone.querySelector(".hostname").innerText = extension.name
                            clone.querySelector(".favicon").src = extension.icons[1].url || fallbackIcon(extension.id, options)
                        } else {
                            clone.querySelector(".hostname").innerText = "Unknown Extension"
                        }
                        mainList.appendChild(clone)
                        siteIndex ++; nextSite()
                    })
                } catch(err) {}
            } else {
                mainList.appendChild(clone)
                siteIndex ++; nextSite()
            }
        }
        nextSite()
        if (siteArray.length == 0) {
            noResults.style.display = "block"
            if (options?.threshold && options?.threshold > 1) {
                noResults.innerText = "Nothing yet! Try reducing the minium site time threshold."
            }
        } else {
            noResults.style.display = "none"
        }
        document.getElementById("total-time").innerText = formatTime(totalTime)
    }).catch((error) => {
        console.error(error)
        document.body.innerHTML = "Whoops, something went wrong!<br><br><strong>Error Information:</strong><br>" + error
    })
}

showAll.addEventListener("click", () => {
    showingAll = true
    refresh()
    showAll.disabled = true 
})

document.getElementById("options").addEventListener("click", () => {
    chrome.runtime.openOptionsPage()
})

refresh()
// setInterval(refresh, 15000)