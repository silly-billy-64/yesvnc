async function getCurrentTab() {
    let queryOptions = { active: true, lastFocusedWindow: true };
    let [tab] = await chrome.tabs.query(queryOptions);
    return tab;
}

function start() {
    chrome.alarms.create('count', {
        delayInMinutes: 1,
        periodInMinutes: 1
    });
}
chrome.runtime.onStartup.addListener(start);
chrome.runtime.onInstalled.addListener(start);

chrome.alarms.onAlarm.addListener((alarm) => {
    chrome.windows.getCurrent().then((browser) => {
        let inFocus = browser.focused
        if (inFocus) {
            chrome.idle.queryState(1800).then((state) => {
                if (state == "active") {
                    getCurrentTab().then((tab) => {
                        if (tab.url) {
                            const url = new URL(tab.url)
                            if (url.hostname) {
                                chrome.storage.local.get().then((result) => {
                                    if (result[url.hostname]) {
                                        chrome.storage.local.set(JSON.parse(`{"${url.hostname}": ${result[url.hostname] + 60}}`)).catch(console.error)
                                    } else {
                                        chrome.storage.local.set(JSON.parse(`{"${url.hostname}": ${60}}`)).catch(console.error)
                                    }
                                })
                                if (tab.favIconUrl && tab.favIconUrl.startsWith("http")) { // Eliminate data uris and inaccessible extension icons
                                    chrome.storage.local.set(JSON.parse(`{"FAVICON_${url.hostname}": "${tab.favIconUrl}"}`))
                                }
                            }
                        }
                    })
                }
            })
        }
    }).catch(() => {})
});