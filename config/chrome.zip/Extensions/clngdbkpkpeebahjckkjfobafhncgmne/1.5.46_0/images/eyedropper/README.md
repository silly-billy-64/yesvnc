Author: DesignContest
License: https://creativecommons.org/licenses/by/4.0/
Source: https://iconarchive.com/show/outline-icons-by-designcontest/Eyedropper-icon.html