# Privacy Policy

Unlike other similar extensions, we don't find you to be all that interesting. Your questionable browsing history should remain between you and the NSA. Stylus collects nothing. Period.

Again, **no data or personal information is collected by Stylus**.

## Contact

If you have any questions or suggestions regarding this privacy policy, do not hesitate to [contact us](stylus.openstyles@gmail.com).
